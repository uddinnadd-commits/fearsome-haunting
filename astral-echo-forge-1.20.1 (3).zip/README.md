# Astral Echo

A night-sky-themed Forge 1.20.1 adventure mod. Hunt drifting Wisps, survive the heavy-hitting Stalker, explore a star-lit forest dimension, then summon its ancient boss.

## The Astral Grove
Craft the **Grove Sigil** from 4 Star Shards, 4 Ender Pearls, and 1 Amethyst Shard. Right-click to travel to the Astral Grove; use it again to return to your Overworld spawn. This custom dimension has a twilight forest biome, Astral Tree generation, unique ambient atmosphere, and a distinct mob roster.

## The boss fight
Craft a **Starfall Totem** from Star Shards, Amethyst, and an Ender Eye. In the Astral Grove, right-click to summon **The Celestial Devourer**. The boss has a 260-health boss bar, custom oversized model, starfall shockwave, dramatic second phase below half health, and exclusive Heart of the Grove and Nether Star loot. Bring friends, good armor, and the Starburst Wand.

## Music and atmosphere
The Astral Grove has its own original looping ambience and a custom soundtrack cue. Collect two original, synth-composed music discs: **Starlit Reverie** is a rare Stellar Wisp drop, and **Devourer’s Waltz** is the Celestial Devourer’s guaranteed trophy. Both play in jukeboxes. The project ZIP also includes the editable, uncompressed soundtrack masters and generator under `docs/audio-source/`; Gradle keeps these source assets out of the playable mod JAR.

## Features
- **Astral Stalker** and particle-trailing **Stellar Wisp** with Overworld spawns.
- **Astral Trees:** custom logs, leaves, and planks with twilight textures.
- **Starfall Ore:** mine with iron or better for Star Shards; smelt for more.
- **Starburst Wand:** ranged burst that damages and knocks back hostiles.
- **Astral Compass:** reveals nearby threats through walls for 10 seconds, up to 32 blocks.
- **Astral Lantern**, custom pixel art, sounds, recipes, particles, mobs, and loot tables.

## Requirements
Minecraft 1.20.1, Forge 47.x (defaults to 47.2.0), Java 17.

## Build
Push to GitHub. `.github/workflows/build.yml` builds on pushes, pull requests, and manual runs; the mod JAR is attached to the workflow run. Locally, use Gradle 8.8 and Java 17, then run `gradle build`. The jar appears in `build/libs/`.

Update `mod_authors` in `gradle.properties` before publishing. MIT license.
