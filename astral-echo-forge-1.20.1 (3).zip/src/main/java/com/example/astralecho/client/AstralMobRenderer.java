package com.example.astralecho.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;

public class AstralMobRenderer<T extends Mob> extends MobRenderer<T, AstralMobModel<T>> {
    private final ResourceLocation texture;
    public AstralMobRenderer(EntityRendererProvider.Context context, float shadowSize, ResourceLocation texture) {
        super(context, new AstralMobModel<>(context.bakeLayer(AstralClientEvents.ASTRAL_MOB_LAYER)), shadowSize);
        this.texture = texture;
    }
    @Override public ResourceLocation getTextureLocation(T entity) { return texture; }
}
