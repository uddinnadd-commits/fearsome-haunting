package com.example.astralecho.event;

import com.example.astralecho.AstralEcho;
import com.example.astralecho.entity.AstralEntities;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntitySpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AstralEcho.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class AstralSpawnEvents {
    @SubscribeEvent
    public static void registerSpawnPlacements(EntitySpawnPlacementRegisterEvent event) {
        event.register(AstralEntities.ASTRAL_STALKER.get(), SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules,
                EntitySpawnPlacementRegisterEvent.Operation.OR);
        event.register(AstralEntities.STELLAR_WISP.get(), SpawnPlacements.Type.NO_RESTRICTIONS,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules,
                EntitySpawnPlacementRegisterEvent.Operation.OR);
    }
    private AstralSpawnEvents() {}
}
