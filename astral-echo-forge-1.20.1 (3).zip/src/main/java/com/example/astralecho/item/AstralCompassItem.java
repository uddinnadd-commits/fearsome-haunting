package com.example.astralecho.item;

import com.example.astralecho.sound.AstralSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

import java.util.List;

public class AstralCompassItem extends Item {
    private static final double RANGE = 32.0D;
    private static final int COOLDOWN_TICKS = 20 * 10;

    public AstralCompassItem(Properties properties) { super(properties); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            List<Monster> monsters = level.getEntitiesOfClass(Monster.class,
                    player.getBoundingBox().inflate(RANGE), Monster::isAlive);
            for (Monster monster : monsters) {
                monster.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.GLOWING, 200));
                if (level instanceof ServerLevel server) {
                    server.sendParticles(ParticleTypes.END_ROD, monster.getX(), monster.getY() + monster.getBbHeight() * 0.5,
                            monster.getZ(), 10, 0.35, 0.45, 0.35, 0.025);
                }
            }
            if (level instanceof ServerLevel server) {
                server.sendParticles(ParticleTypes.FIREWORK, player.getX(), player.getY() + 1.0, player.getZ(),
                        28, 1.5, 0.8, 1.5, 0.04);
            }
            level.playSound(null, player.blockPosition(), AstralSounds.ASTRAL_BURST.get(), SoundSource.PLAYERS, 0.9F, 0.8F);
            player.displayClientMessage(Component.literal(monsters.isEmpty()
                    ? "The stars are quiet... no threats nearby."
                    : "✦ Astral Echo reveals " + monsters.size() + (monsters.size() == 1 ? " threat!" : " threats!")), true);
            player.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
