package com.example.astralecho;

import com.example.astralecho.block.AstralBlocks;
import com.example.astralecho.entity.AstralEntities;
import com.example.astralecho.item.AstralItems;
import com.example.astralecho.sound.AstralSounds;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(AstralEcho.MOD_ID)
public class AstralEcho {
    public static final String MOD_ID = "astral_echo";
    public AstralEcho() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        AstralItems.ITEMS.register(bus);
        AstralBlocks.BLOCKS.register(bus);
        AstralBlocks.BLOCK_ITEMS.register(bus);
        AstralEntities.ENTITY_TYPES.register(bus);
        AstralSounds.SOUNDS.register(bus);
        bus.addListener(this::addCreativeTabItems);
        bus.addListener(this::registerEntityAttributes);
    }

    private void addCreativeTabItems(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(com.example.astralecho.item.AstralItems.STARFALL_TOTEM);
            event.accept(AstralItems.ASTRAL_COMPASS);
            event.accept(AstralItems.STARBURST_WAND);
            event.accept(AstralItems.GROVE_SIGIL);
            event.accept(AstralItems.STARLIGHT_RECORD);
            event.accept(AstralItems.DEVOURER_RECORD);
        }
        if (event.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
            event.accept(AstralBlocks.ASTRAL_LANTERN_ITEM);
            event.accept(AstralBlocks.ASTRAL_LOG_ITEM);
            event.accept(AstralBlocks.ASTRAL_PLANKS_ITEM);
        }
        if (event.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
            event.accept(AstralBlocks.STARFALL_ORE_ITEM);
            event.accept(AstralBlocks.ASTRAL_LEAVES_ITEM);
        }
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(AstralItems.STAR_SHARD);
            event.accept(AstralItems.STARHEART);
        }
    }

    private void registerEntityAttributes(EntityAttributeCreationEvent event) {
        event.put(AstralEntities.ASTRAL_STALKER.get(), com.example.astralecho.entity.AstralStalker.createAttributes().build());
        event.put(AstralEntities.STELLAR_WISP.get(), com.example.astralecho.entity.StellarWisp.createAttributes().build());
        event.put(AstralEntities.CELESTIAL_DEVOURER.get(), com.example.astralecho.entity.CelestialDevourer.createAttributes().build());
    }
}
