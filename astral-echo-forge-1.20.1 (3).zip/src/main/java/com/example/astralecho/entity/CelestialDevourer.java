package com.example.astralecho.entity;

import com.example.astralecho.sound.AstralSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class CelestialDevourer extends Monster {
    private final ServerBossEvent bossEvent = new ServerBossEvent(
            Component.literal("THE CELESTIAL DEVOURER"), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);
    private int pulseCooldown = 90;
    private boolean enteredSecondPhase;

    public CelestialDevourer(EntityType<? extends CelestialDevourer> type, Level level) {
        super(type, level);
        setPersistenceRequired();
        setCustomName(Component.literal("✦ The Celestial Devourer ✦"));
        setCustomNameVisible(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, 260.0)
                .add(Attributes.MOVEMENT_SPEED, 0.31).add(Attributes.ATTACK_DAMAGE, 13.0)
                .add(Attributes.FOLLOW_RANGE, 64.0).add(Attributes.KNOCKBACK_RESISTANCE, 0.8)
                .add(Attributes.ARMOR, 10.0);
    }

    @Override protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2, false));
        goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.7));
        goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 20.0F));
        goalSelector.addGoal(9, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override public void tick() {
        super.tick();
        if (level().isClientSide) return;
        bossEvent.setProgress(Math.max(0.0F, getHealth() / getMaxHealth()));
        if (level() instanceof ServerLevel server && tickCount % 4 == 0) {
            server.sendParticles(ParticleTypes.DRAGON_BREATH, getX(), getY() + getBbHeight() * 0.7, getZ(),
                    5, 0.65, 0.75, 0.65, 0.015);
            server.sendParticles(ParticleTypes.END_ROD, getX(), getY() + 0.4, getZ(), 2,
                    0.8, 0.2, 0.8, 0.01);
        }
        if (!enteredSecondPhase && getHealth() <= getMaxHealth() * 0.5F) {
            enteredSecondPhase = true;
            pulseCooldown = 45;
            if (level() instanceof ServerLevel server) {
                server.sendParticles(ParticleTypes.EXPLOSION_EMITTER, getX(), getY() + 1.4, getZ(), 2, 1, 1, 1, 0.0);
                server.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, getX(), getY() + 1.4, getZ(), 100, 1.4, 1.5, 1.4, 0.08);
                server.getPlayers(p -> p.distanceToSqr(this) < 4096).forEach(p -> p.displayClientMessage(
                        Component.literal("THE DEVOURER ENTERS ITS STARFALL PHASE!"), true));
            }
            level().playSound(null, blockPosition(), AstralSounds.ASTRAL_BURST.get(), net.minecraft.sounds.SoundSource.HOSTILE, 2.5F, 0.55F);
        }
        if (--pulseCooldown <= 0) unleashStarfall();
    }

    private void unleashStarfall() {
        int radius = enteredSecondPhase ? 12 : 9;
        if (level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 1.2, getZ(), 1, 0, 0, 0, 0.0);
            server.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, getX(), getY() + 1.0, getZ(), 100,
                    radius / 2.0, 0.6, radius / 2.0, 0.04);
            server.sendParticles(ParticleTypes.END_ROD, getX(), getY() + 1.0, getZ(), 60,
                    radius / 2.0, 0.9, radius / 2.0, 0.07);
        }
        level().playSound(null, blockPosition(), AstralSounds.ASTRAL_BURST.get(), net.minecraft.sounds.SoundSource.HOSTILE, 2.0F, 0.72F);
        for (Player player : level().getEntitiesOfClass(Player.class, new AABB(blockPosition()).inflate(radius))) {
            double distance = player.distanceTo(this);
            if (distance <= radius) {
                player.hurt(damageSources().mobAttack(this), enteredSecondPhase ? 10.0F : 7.0F);
                Vec3 push = player.position().subtract(position()).normalize().scale(1.4);
                player.push(push.x, 0.65, push.z);
                player.hurtMarked = true;
            }
        }
        pulseCooldown = enteredSecondPhase ? 70 : 115;
    }

    @Override public void startSeenByPlayer(ServerPlayer player) { super.startSeenByPlayer(player); bossEvent.addPlayer(player); }
    @Override public void stopSeenByPlayer(ServerPlayer player) { super.stopSeenByPlayer(player); bossEvent.removePlayer(player); }
    @Override public boolean canBeLeashed() { return false; }
}
