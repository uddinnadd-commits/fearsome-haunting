package com.example.astralecho.entity;

import com.example.astralecho.AstralEcho;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class AstralEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, AstralEcho.MOD_ID);

    public static final RegistryObject<EntityType<AstralStalker>> ASTRAL_STALKER = ENTITY_TYPES.register("astral_stalker",
            () -> EntityType.Builder.of(AstralStalker::new, MobCategory.MONSTER).sized(0.72F, 2.05F)
                    .clientTrackingRange(8).build("astral_echo:astral_stalker"));
    public static final RegistryObject<EntityType<StellarWisp>> STELLAR_WISP = ENTITY_TYPES.register("stellar_wisp",
            () -> EntityType.Builder.of(StellarWisp::new, MobCategory.MONSTER).sized(0.8F, 0.9F)
                    .clientTrackingRange(10).build("astral_echo:stellar_wisp"));

    public static final RegistryObject<EntityType<CelestialDevourer>> CELESTIAL_DEVOURER = ENTITY_TYPES.register("celestial_devourer",
            () -> EntityType.Builder.of(CelestialDevourer::new, MobCategory.MONSTER).sized(1.45F, 3.25F)
                    .clientTrackingRange(12).build("astral_echo:celestial_devourer"));

    private AstralEntities() {}
}
